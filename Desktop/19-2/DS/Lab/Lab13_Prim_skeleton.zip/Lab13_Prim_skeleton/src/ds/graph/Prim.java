package ds.graph;


public class Prim {

    public static void findMST(Graph G) {
        // TODO: Fill in your code
		//print(G, parent);
    }


    public static void print(Graph G, int[] parent) {
        // TODO: Fill in your code
    }

    public static int getNextVertex(Graph G, double key[], Boolean isVisited[]) {
    	// TODO: Fill in your code
		return -1;
    }

}
